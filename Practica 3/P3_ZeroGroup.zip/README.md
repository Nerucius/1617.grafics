

Informe
	https://docs.google.com/document/d/1ggtEf8VLIOMooeTP6xRvCnYxYTKbS-lE5N84sIoyJdg/edit?usp=sharing
	

Reparto de Tareas
	- Buscar la Base de Datos:								Alvaro Ortega
	- Tratar los datos para hacerlos aptos para la App:		German Dempere
	- Editar los Shaders y demas aspectos Visuales			German Dempere